// src/DNs/raftNode.js
const LifeRaft = require('liferaft');
const axios = require('axios');

class RaftNode extends LifeRaft {
    constructor(id, peers) {
        super(id);
        this.peers = peers;
        this.on('term change', this.onTermChange.bind(this));
        this.on('leader change', this.onLeaderChange.bind(this));
    }

    onTermChange(term) {
        console.log(`Node ${this.id} - Term changed to ${term}`);
    }

    onLeaderChange(leader) {
        console.log(`Node ${this.id} - Leader changed to ${leader}`);
        if (this.id === leader) {
            // If this node is the leader, announce it to the RP
            axios.get('http://rp-server-ip/set_master', {
                params: { leader: this.id }
            }).catch(error => {
                console.error('Error announcing leader:', error.message);
            });
        }
    }

    // Define how this node communicates with other nodes
    send(to, message, callback) {
        axios.post(`http://${to}/raft`, message)
            .then(response => callback(null, response.data))
            .catch(error => callback(error));
    }

    // Handle incoming messages from other nodes
    handleMessage(req, res) {
        this.emit(req.body.type, req.body, res);
    }
}

module.exports = RaftNode;
